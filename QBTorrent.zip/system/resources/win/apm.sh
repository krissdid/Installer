#!/bin/sh

"$(dirname "$0")/../app/apm/bin/apm" "$@"
