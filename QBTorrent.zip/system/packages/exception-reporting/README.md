## Exception Reporting package

Reports uncaught exceptions in Atom to [bugsnag](https://bugsnag.com).
